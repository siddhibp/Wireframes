import React from 'react';

export default function About(props) {
/*  const [myStyle, setMyStyle] = useState({
    color: 'black',
    backgroundColor: 'white',
  });
*/
let myStyle={
  color:props.mode ==='dark'? 'white':'#042743',
  backgroundColor:props.mode === 'dark'? 'rgb(36 74 104':'#D3D3D3',
  border:'2px transparent',
  borderColor:props.mode==='dark'? 'white':'#042743',
}



  return (
    <div className="container" style={{color:props.mode ==='dark'? 'white':'#042743',}}>
      <h2 align="center">About us</h2>
      <p >Lorem Use card groups to render cards as a single, attached element with equal width and height columns. Card groups start off stacked and use display: flex; to become attached with uniform dimensions starting at the sm breakpoint.</p>

      <div className="accordion" id="accordionPanelsStayOpenExample">
      <div class="row row-cols-1 row-cols-md-3 g-4">
  <div class="col">
    <div class="card">
      <img src="https://hbr.org/resources/images/article_assets/2024/07/July24_19_1234856497.jpg" class="card-img-top" alt="..."></img>
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        <a href="#" rel="noreferrer" target="_blank" className="btn btn-sm btn-dark">View</a>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="https://hbr.org/resources/images/article_assets/2024/07/July24_19_1234856497.jpg" class="card-img-top" alt="..."></img>
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        <a href="#" rel="noreferrer" target="_blank" className="btn btn-sm btn-dark">View</a>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="https://hbr.org/resources/images/article_assets/2024/07/July24_19_1234856497.jpg" class="card-img-top" alt="..."></img>
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content.</p>
        <a href="#" rel="noreferrer" target="_blank" className="btn btn-sm btn-dark">View</a>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="https://hbr.org/resources/images/article_assets/2024/07/July24_19_1234856497.jpg" class="card-img-top" alt="..."></img>
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        <a href="#" rel="noreferrer" target="_blank" className="btn btn-sm btn-dark">View</a>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="https://hbr.org/resources/images/article_assets/2024/07/July24_19_1234856497.jpg" class="card-img-top" alt="..."></img>
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content.</p>
        <a href="#" rel="noreferrer" target="_blank" className="btn btn-sm btn-dark">View</a>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="https://hbr.org/resources/images/article_assets/2024/07/July24_19_1234856497.jpg" class="card-img-top" alt="..."></img>
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content.</p>
        <a href="#" rel="noreferrer" target="_blank" className="btn btn-sm btn-dark">View</a>
      </div>
    </div>
  </div>
  
</div>
      </div>
      <section class="footer">
      <div class="footer-row">
        
        <div class="footer-col mt-4">
          
          <p align="center">
            Copyright @Siddhi
            Subscribe to our newsletter for a weekly dose
            of news, updates, helpful tips, and
            exclusive offers.
          </p>
          
         
        </div>
      </div>
    </section> 
      </div>

  );
}
